import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Date fecha=new Date();
        System.out.printf("%20s\n","Hola Mundo");
        System.out.printf("\n ===============================\n");
        System.out.printf("Mi nombre es, Ainhoa\n");
        System.out.printf("\nHoy es,%d/%d/%d %d:%d",fecha.getDate(),fecha.getMonth()+1,fecha.getYear()+1900,fecha.getHours(),fecha.getMinutes());

    }
}